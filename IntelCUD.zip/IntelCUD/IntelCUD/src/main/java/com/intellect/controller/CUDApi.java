package com.intellect.controller;

import java.util.ArrayList;

import javax.annotation.sql.DataSourceDefinition;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.intellect.Entity.UserEntity;
import com.intellect.VO.RequestValueVO;
import com.intellect.VO.ResponseValueVO;

import com.intellect.view.Repository;

@RestController
public class CUDApi {

	@Autowired
	Repository repository;

	

	// u1.setter

	@RequestMapping(value = "/create", produces = "application/json", method = RequestMethod.POST, consumes = "application/json")
	public ResponseEntity<ResponseValueVO> crtUser(@RequestBody RequestValueVO req) {
		ArrayList<RequestValueVO> al = new ArrayList<RequestValueVO>();
		// Add for our local validation
		RequestValueVO u1 = new RequestValueVO();
		u1.setEmail("intellectCUD@gmail.com");
		al.add(u1);
		UserEntity entry = new UserEntity();
		ResponseValueVO res = new ResponseValueVO();
		boolean isNewUser=true;
		
		HttpHeaders responseHeaders = new HttpHeaders();  
		//ResponseEntity resEnt = new ResponseEntity(null);
		//HttpStatus httpstatus =new HttpStatus();
		
		res=validateInputFields(req, "create");// Validation 
		
		if ( res.getErrors().isEmpty()){
		for (RequestValueVO reqValVo : al){			
			if ( reqValVo.getEmail().equalsIgnoreCase(req.getEmail())){
				isNewUser=false;
			}
			
		}
		if (isNewUser) {
			
			entry.setBirthDate(req.getBirthDate());
			entry.setEmail(req.getEmail());
			entry.setfName(req.getfName());
			entry.setlName(req.getlName());
			entry.setPinCode(req.getPinCode());
			repository.save(entry);

			// Saving data in list
			RequestValueVO user1 = new RequestValueVO();
			user1.setBirthDate(req.getBirthDate());
			user1.setEmail(req.getEmail());
			user1.setfName(req.getfName());
			user1.setlName(req.getlName());
			user1.setPinCode(req.getPinCode());

			res.setResMsg(" Request has updated successfully ");
			res.setUserId(entry.getId());

		} else {
			
			ArrayList<String> errorList = new ArrayList<String>();
			errorList.add("User is exists already. ");
			res.setErrors(errorList);

		}
		}

		return new ResponseEntity <ResponseValueVO>(res,responseHeaders, HttpStatus.CREATED) ;

	}

	@RequestMapping(value = "/update", produces = "application/json", method = RequestMethod.POST, consumes = "application/json")
	public ResponseEntity<ResponseValueVO> updateUser(@RequestBody RequestValueVO req) {
		ArrayList<RequestValueVO> al = new ArrayList<RequestValueVO>();
		// Add for our local validation
		RequestValueVO u1 = new RequestValueVO();
		u1.setId(123);
		al.add(u1);
		UserEntity entry = new UserEntity();
		ResponseValueVO res = new ResponseValueVO();
		boolean isUpdate=false;
		
		HttpHeaders responseHeaders = new HttpHeaders();  
		//ResponseEntity resEnt = new ResponseEntity(null);
		//HttpStatus httpstatus =new HttpStatus();
		
		
		for (RequestValueVO reqValVo : al){			
			if ( reqValVo.getId()==(req.getId())){
				isUpdate=true;
				break;
			}
			
		}
		if (isUpdate) {
			
			entry.setBirthDate(req.getBirthDate());
			entry.setPinCode(req.getPinCode());
			repository.save(entry);

			// Saving data in list
			/*RequestValueVO user1 = new RequestValueVO();
			user1.setBirthDate(req.getBirthDate());
			user1.setEmail(req.getEmail());
			user1.setfName(req.getfName());
			user1.setlName(req.getlName());
			user1.setPinCode(req.getPinCode());*/

			res.setResMsg(" User data has been updated successfully ");
			res.setUserId(entry.getId());

		} else {
			
			ArrayList<String> errorList = new ArrayList<String>();
			errorList.add("User is not available for the user ID .Hence unable to perform the update call ");
			res.setErrors(errorList);

		}

		return new ResponseEntity <ResponseValueVO>(res,responseHeaders, HttpStatus.CREATED) ;

	}

	@RequestMapping(value = "/delete", produces = "application/json", method = RequestMethod.PUT, consumes = "application/json")
	public ResponseEntity<ResponseValueVO> deleteUser(@RequestBody RequestValueVO req) {
		ArrayList<RequestValueVO> al = new ArrayList<RequestValueVO>();
		// Add for our local validation
		RequestValueVO u1 = new RequestValueVO();
		u1.setId(123);
		al.add(u1);
		UserEntity entry = new UserEntity();
		ResponseValueVO res = new ResponseValueVO();
		boolean isUpdate=false;
		
		HttpHeaders responseHeaders = new HttpHeaders();  
		//ResponseEntity resEnt = new ResponseEntity(null);
		//HttpStatus httpstatus =new HttpStatus();
		
		
		for (RequestValueVO reqValVo : al){			
			if ( reqValVo.getId()==(req.getId())){
				isUpdate=true;
				break;
			}
			
		}
		if (isUpdate) {
			
			
			//entry.setBirthDate(req.getBirthDate());
			//entry.setPinCode(req.getPinCode());
			repository.delete(entry); //Bassed on User ID

			// Saving data in list
			/*RequestValueVO user1 = new RequestValueVO();
			user1.setBirthDate(req.getBirthDate());
			user1.setEmail(req.getEmail());
			user1.setfName(req.getfName());
			user1.setlName(req.getlName());
			user1.setPinCode(req.getPinCode());*/

			res.setResMsg(" Delete operation has updated successfully ");
			res.setUserId(entry.getId());

		} else {
			
			ArrayList<String> errorList = new ArrayList<String>();
			errorList.add("User is not available for the user ID .Hence unable to perform the delete call ");
			res.setErrors(errorList);

		}

		return new ResponseEntity <ResponseValueVO>(res,responseHeaders, HttpStatus.OK) ;

	}

	//Need to move this validation method in constant class 
	ResponseValueVO validateInputFields(RequestValueVO req, String operation ){
		ResponseValueVO res= new ResponseValueVO();
		ArrayList<String> errorList = new ArrayList<String>();
		
		
		if (operation.equalsIgnoreCase("create") ){//we can add other element valdiation here 
		if ( req.getEmail() == null || req.getEmail().equalsIgnoreCase("") )	{
			errorList.add("User email  is null or empty ");
		}
		} else 	if (operation.equalsIgnoreCase("update") ){//we can add other element valdiation here 
			if ( req.getPinCode() != null || req.getPinCode().equalsIgnoreCase("") )	{
				errorList.add("User pin code and birthdate   should not be  null or empty ");
			}
			}
		
		res.setErrors(errorList);
			
		
		return res;
	}
}
